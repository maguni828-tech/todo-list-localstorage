
import React, {useState} from 'react'
import api from '../api/axios'
import { useNavigate } from 'react-router-dom'
export default function Signup(){ const [loginId,setLoginId]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const nav=useNavigate();
  async function submit(){ try{ await api.post('/auth/signup',{loginId,email,password}); alert('Signup success, please login'); nav('/login'); }catch(e){ alert(e.response?.data?.message || 'Signup failed') } }
  return (<div style={{padding:20}}><h2>Signup</h2><div><input placeholder='loginId' value={loginId} onChange={e=>setLoginId(e.target.value)} /></div><div><input placeholder='email' value={email} onChange={e=>setEmail(e.target.value)} /></div><div><input placeholder='password' type='password' value={password} onChange={e=>setPassword(e.target.value)} /></div><div><button onClick={submit}>Signup</button> <button onClick={()=>nav('/login')}>Login</button></div></div>) }
