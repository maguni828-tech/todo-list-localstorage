
package com.example.todo.dto;

import lombok.*;

@Data
public class AuthRequest {
    private String loginId;
    private String password;
    private String email;
    private String userName;
}
