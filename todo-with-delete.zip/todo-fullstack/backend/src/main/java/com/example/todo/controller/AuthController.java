
package com.example.todo.controller;

import com.example.todo.dto.AuthRequest;
import com.example.todo.entity.User;
import com.example.todo.repository.UserRepository;
import com.example.todo.config.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtProvider;

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody AuthRequest req) {
        if (req.getLoginId() == null || req.getPassword() == null || req.getEmail() == null) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Required fields missing"));
        }
        User u = User.builder().loginId(req.getLoginId()).email(req.getEmail()).userName(req.getUserName()).password(passwordEncoder.encode(req.getPassword())).build();
        userRepository.save(u);
        return ResponseEntity.status(201).body(Map.of("success", true, "message", "회원가입 완료" , "user_id", u.getId()));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest req) {
        var opt = userRepository.findByLoginId(req.getLoginId());
        if (opt.isEmpty()) return ResponseEntity.status(401).body(Map.of("success", false, "message", "Invalid credentials"));
        var user = opt.get();
        if (!passwordEncoder.matches(req.getPassword(), user.getPassword())) return ResponseEntity.status(401).body(Map.of("success", false, "message", "Invalid credentials"));
        String token = jwtProvider.createToken(user.getLoginId(), user.getId());
        return ResponseEntity.ok(Map.of("success", true, "token", token, "user", Map.of("user_id", user.getId(), "login_id", user.getLoginId(), "email", user.getEmail())));
    }
}
