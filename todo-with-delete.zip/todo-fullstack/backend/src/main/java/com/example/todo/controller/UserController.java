package com.example.todo.controller;

import com.example.todo.repository.UserRepository;
import com.example.todo.repository.TodoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {
    private final UserRepository userRepository;
    private final TodoRepository todoRepository;

    /** 내 정보 조회 */
    @GetMapping("/me")
    public ResponseEntity<?> me(Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).build();
        Long userId = Long.valueOf(String.valueOf(auth.getPrincipal()));
        return userRepository.findById(userId)
                .map(u -> Map.of(
                        "user_id", u.getId(),
                        "login_id", u.getLoginId(),
                        "email", u.getEmail()
                ))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(404).build());
    }

    /** 회원 탈퇴 */
    @DeleteMapping("/me")
    public ResponseEntity<?> deleteMe(Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).body(Map.of("success", false, "message", "로그인 필요"));
        Long userId = Long.valueOf(String.valueOf(auth.getPrincipal()));

        // 관련 To do 삭제 후 사용자 삭제
        todoRepository.deleteAll(todoRepository.findByUserIdOrderByIdDesc(userId));
        userRepository.deleteById(userId);

        return ResponseEntity.ok(Map.of("success", true, "message", "회원 탈퇴 완료"));
    }
}
