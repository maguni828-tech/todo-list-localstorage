
import React, {useEffect, useState} from 'react'
import api from '../api/axios'
import { useNavigate } from 'react-router-dom'
export default function TodoList(){ const [todos,setTodos]=useState([]); const [title,setTitle]=useState(''); const nav=useNavigate();
  useEffect(()=>{ load() }, [])
  async function load(){ try{ const res = await api.get('/todos'); setTodos(res.data); }catch(e){ alert('Please login'); nav('/login') } }
  async function add(){ if(!title) return; await api.post('/todos',{ title }); setTitle(''); load(); }
  async function toggle(t){ await api.patch(`/todos/${t.id}/status`, { status: t.status==='done' ? 'doing' : 'done' }); load(); }
  async function del(t){ await api.delete(`/todos/${t.id}`); load(); }
  function logout(){ localStorage.removeItem('token'); nav('/login') }
  return (<div style={{padding:20}}><h2>To do List</h2><div><button onClick={logout}>Logout</button></div><div style={{marginTop:12}}><input placeholder='new todo' value={title} onChange={e=>setTitle(e.target.value)} /><button onClick={add}>Add</button></div><ul>{todos.map(t => (<li key={t.id}>{t.title} ({t.status}) <button onClick={()=>toggle(t)}>Toggle</button> <button onClick={()=>del(t)}>Del</button></li>))}</ul></div>) }
