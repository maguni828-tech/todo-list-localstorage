
package com.example.todo.controller;

import com.example.todo.dto.TodoDto;
import com.example.todo.entity.Todo;
import com.example.todo.entity.User;
import com.example.todo.repository.TodoRepository;
import com.example.todo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/todos")
@RequiredArgsConstructor
public class TodoController {
    private final TodoRepository todoRepo;
    private final UserRepository userRepo;

    @GetMapping
    public ResponseEntity<?> list(Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).build();
        Long userId = Long.valueOf(String.valueOf(auth.getPrincipal()));
        List<Todo> items = todoRepo.findByUserIdOrderByIdDesc(userId);
        var dtos = items.stream().map(t -> {
            TodoDto d = new TodoDto();
            d.setId(t.getId()); d.setTitle(t.getTitle()); d.setDescription(t.getDescription());
            d.setStatus(t.getStatus()); d.setFinishDate(t.getFinishDate());
            return d;
        }).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PostMapping
    public ResponseEntity<?> create(Authentication auth, @RequestBody TodoDto dto) {
        if (auth == null) return ResponseEntity.status(401).build();
        Long userId = Long.valueOf(String.valueOf(auth.getPrincipal()));
        User u = userRepo.findById(userId).orElseThrow();
        Todo t = Todo.builder().user(u).title(dto.getTitle()).description(dto.getDescription()).status(dto.getStatus()!=null?dto.getStatus():"doing").finishDate(dto.getFinishDate()).build();
        todoRepo.save(t);
        return ResponseEntity.status(201).body(Map.of("success", true, "progress_id", t.getId()));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody TodoDto dto, Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).build();
        var opt = todoRepo.findById(id);
        if (opt.isEmpty()) return ResponseEntity.status(404).body(Map.of("success", false, "message", "Not found"));
        var t = opt.get();
        if (dto.getTitle() != null) t.setTitle(dto.getTitle());
        t.setDescription(dto.getDescription()); t.setStatus(dto.getStatus()); t.setFinishDate(dto.getFinishDate());
        todoRepo.save(t);
        return ResponseEntity.ok(Map.of("success", true, "message", "업데이트 완료"));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<?> status(@PathVariable Long id, @RequestBody Map<String,String> body, Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).build();
        String status = body.get("status"); if (status==null) return ResponseEntity.badRequest().build();
        var opt = todoRepo.findById(id); if (opt.isEmpty()) return ResponseEntity.status(404).build();
        var t = opt.get(); t.setStatus(status); todoRepo.save(t);
        return ResponseEntity.ok(Map.of("success", true));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id, Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).build();
        todoRepo.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "삭제 완료"));
    }
}
