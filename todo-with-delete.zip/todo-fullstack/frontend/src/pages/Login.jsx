
import React, {useState} from 'react'
import api from '../api/axios'
import { useNavigate } from 'react-router-dom'
export default function Login(){ const [loginId,setLoginId]=useState(''); const [password,setPassword]=useState(''); const nav=useNavigate();
  async function submit(){ try{ const res = await api.post('/auth/login',{loginId,password}); localStorage.setItem('token', res.data.token); nav('/todos'); }catch(e){ alert(e.response?.data?.message || 'Login failed') } }
  return (<div style={{padding:20}}><h2>Login</h2><div><input placeholder='loginId' value={loginId} onChange={e=>setLoginId(e.target.value)} /></div><div><input placeholder='password' type='password' value={password} onChange={e=>setPassword(e.target.value)} /></div><div><button onClick={submit}>Login</button> <button onClick={()=>nav('/signup')}>Signup</button></div></div>) }
